** CANCOICODE THEME **
Auteurs : Sandrine Mathieu / Charlie Moreau / Yohann Thorez
@2018 - ACS - VESOUL

FONTS : 
	- RALEWAY MEDIUM
	- RALEWAY EXTRABOLD
	- LATO REGULAR
	- FONTAWESOME

COULEURS :
	- #FFF / BLANC
	- #000 / NOIR
	- #b11e2f / ROUGE CERISE


INSTRUCTIONS : 
	- PASSER LES IMAGES sur TINYJPG
	- PAS DE CDN
	- UTILISATION DE BOOTSTRAP 4
	- EN DEHORS DES PHOTOS : UNIQUEMENT DU SVG

	- LE LOGO CANCOICODE DOIT TOURNER SUR LUI MEME EN ANIMATION
	- HOVER SUR LES MINIATURES DES ARTICLES ET DES PROJETS
	- MENU BURGER SUR LA DROITE POUR FORMAT MOBILE

FEATURES :
	- "cancoicode" code ---> Une boite � meuh qui fait un son en plein milieu de l'�cran
	- Page "/cancoicode" non r�pertori� dans le site ---> Page troll "Fausse page de publicit� cancoicode"
	  Sur le titre "Bienvenue sur le blog /cancoicode", /cancoicode s'affiche comme si on le tape.

RESSOURCES : 
	- JQUERY 3.2.1
	- BOOTSTRAP 4

PLUGIN :
	- CUSTOM POST UI
	- ADVANCED CUSTOM FIELD
	
	
